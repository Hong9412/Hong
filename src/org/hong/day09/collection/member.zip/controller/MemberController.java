package org.hong.day09.collection.member.controller;

public class MemberController {

}
