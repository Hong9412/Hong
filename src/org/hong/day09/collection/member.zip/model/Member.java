package org.hong.day09.collection.member.model;

public class Member {

}
