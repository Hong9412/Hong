package org.hong.day09.collection.member.view;

public class MemberView {

}
