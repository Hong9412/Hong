package org.hong.day09.collection.member.run;

public class MemberRun {

}
